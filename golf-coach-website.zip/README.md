<!doctype html><html><head><link rel='stylesheet' href='assets/css/style.css'></head><body># Golf Coach Website
Upload to GitHub Pages or Vercel.<p><a href='index.html'>Home</a></p></body></html>